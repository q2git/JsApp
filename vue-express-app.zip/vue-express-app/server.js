const express=require('express')
const bodyParser=require('body-parser')
const passport=require('passport')
const indexRouter=require('./routes')
const usersRouter=require('./routes/api/users.js')
const rmsRouter=require('./routes/api/rms')

const app=express()
const port=5000

//user body-parser middle-ware
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

//passport initialization, for JWT
app.use(passport.initialize())
require('./config/passport')(passport);

//router
app.use('/',indexRouter)

//routers
app.use('/api/users', usersRouter)
app.use('/api/rms', rmsRouter)

app.listen(port)
console.log('listen at '+port)