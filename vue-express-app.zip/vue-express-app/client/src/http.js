import axios from 'axios'
import {Loading, Message} from 'element-ui'
import router from './router'

let loading;
function startLoading(){
    loading=Loading.service({
        lock: true,
        text: 'loading...',
        background: 'rgba(0,0,0,0.7)'
    })
}

function endLoading(){
    loading.close();
}

//request interception
axios.interceptors.request.use(
    config=>{
        //loading animation
        startLoading();

        //set standard request header
        if(localStorage.eleToken){
            config.headers.Authorization=localStorage.eleToken;
        }

        return config;
    }, 
    error=>{
        return Promise.reject(error);
    }
)

//response interception
axios.interceptors.response.use(
    response=>{
        //ending animation
        endLoading();
        return response;
    },
    error=>{
        //error reminding
        endLoading();
        Message.error(error.response.data);

        //get error status code
        const {status}=error.response;
        //HTTP 错误 401.1 - 未经授权
        if(status==401){
            Message.error('token expired, please login again!');
            //clear expired token
            localStorage.removeItem('eleToken');
            //jump to login page
            router.push('/login');
        }
        return Promise.reject(error);
    }
)


export default axios;