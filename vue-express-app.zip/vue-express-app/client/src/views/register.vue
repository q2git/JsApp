<template>
    <div class='register'>
        <section class="form_container">
            <div class="manage_tip">
                <span class="title">Repair Management System</span>
                <el-form :model="registerUser" status-icon :rules="rules" ref="registerForm" 
                label-width="80px" class="registerForm">
                    <el-form-item label="Name" prop="name">
                        <el-input v-model="registerUser.name" placeholder="Please input your name"></el-input>
                    </el-form-item>
                    <el-form-item label="Email" prop="email">
                        <el-input v-model="registerUser.email" placeholder="Please input your email"></el-input>
                    </el-form-item>
                    <el-form-item label="Password" prop="password">
                        <el-input type="password" v-model="registerUser.password" placeholder="Please input your password"></el-input>
                    </el-form-item>
                    <el-form-item label="Confirm" prop="password2">
                        <el-input type="password" v-model="registerUser.password2" placeholder="Please input confirm your password"></el-input>
                    </el-form-item>
                    <el-form-item label="Role">
                        <el-select v-model="registerUser.role" placeholder='Please select your role'>
                            <el-option label='User' value='user'></el-option>
                            <el-option label='Admin' value='admin'></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item>                
                        <el-button type='primary' class="submit_btn" @click="submitForm('registerForm')">Register</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: 'register',
        components: {},
        data(){
            var validatePass = (rule, value, callback) => {
                if (value !== this.registerUser.password) {
                callback(new Error('两次输入密码不一致!'));
                } else {
                callback();
                }
            };
            return{
                registerUser:{
                    name: '',
                    email: '',
                    password: '',
                    password2: '',
                    role: ''
                },
                rules:{
                    name: [
                        {required:true,message:'Name is required',trigger:'blur'},
                        {min:2,max:30,message:'Length must be in 2~30',trigger:'blur'}
                    ],
                    email: [
                        {type:'email',required:true,message:'Wrong format',trigger:'blur'}
                    ],
                    password: [
                        {required:true,message:'Password is requried',trigger:'blur'},
                        {min:6,max:30,message:'Length must be in 6~30',trigger:'blur'}
                    ],
                    password2: [
                        {validator:validatePass,trigger:'blur'}
                    ]
                }
            }
        },
        methods:{
            submitForm(formName){
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$axios.post('/api/users/register',this.registerUser)
                        .then(res=>{
                            //sucess
                            this.$message({
                                message:'register successfully',
                                type: 'success'
                            })
                            //jump to login page
                            this.$router.push('/login')
                        })
                        .catch(err=>{
                            //not necessary, http.js interception will handle it   
                        })
                    } 
                });
            }
        }
    }
</script>

<style lang="css" scoped>
.register{
    position: relative;
    width: 100%;
    height: 100%;
    background: url(../assets/bg.jpg) no-repeat center center;
    background-size: 100% 100%;
}
.form_container{
    width: 370px;
    height: 210px;
    position: absolute;
    top: 10%;
    left: 34%;
    padding: 25px;
    border-radius: 5px;
    text-align: center;
}
.form_container .manage_tip .title{
    font-family: 'Arial';
    font-weight: bold;
    font-size: 26px;
    color: #FFF;
}
.registerForm{
    margin-top: 20px;
    background-color: #fff;
    padding: 20px 40px 20px 20px;
    border-radius: 5px;
    box-shadow: 0px 5px 10px #cccc;
}
.submit_btn{
    width: 100%;
}
</style>