<template>
    <div class='index'>
        <Header></Header>
        <LeftMenu></LeftMenu>
        <div class="rightContainer">
            <router-view></router-view>
        </div> 
    </div>
</template>

<script>
import Header from '../components/header'
import LeftMenu from '../components/leftmenu'

export default {
    name: 'index',
    components: {
        Header,
        LeftMenu
    }
}
</script>

<style lang="css" scoped>
.index {
    width: 100%;
    height: 100%;
    overflow: hidden;
}
.rightContainer {
  position: relative;
  top: 0;
  left: 180px;
  width: calc(100% - 180px);
  height: calc(100% - 71px);
  overflow: auto;
}
</style>