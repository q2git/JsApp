<template>
  <div class="fillContainer">
    <div>
      <el-form :inline="true">
        <el-form-item label='Sort by Date'>
          <el-date-picker
            v-model="search_data.startTime"
            type="datetime"
            placeholder="start date"
            >
          </el-date-picker>
          --
          <el-date-picker
            v-model="search_data.endTime"
            type="datetime"
            placeholder="end date"
            >
          </el-date-picker>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" size ="small" icon="search" @click='handleSearch()'>Search</el-button>
        </el-form-item>
        <el-form-item class="btnRight">
            <el-button 
            type="primary" 
            size ="small" 
            icon="view" 
            v-if='user.role=="admin"'
            @click='handleAdd()'>ADD</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table_container">
      <el-table
        v-if='tableData.length>0'
        :data="tableData"
        border
        style="width: 100%">
        <el-table-column
          type="index"
          label="No."
          align='center'
          width="70">
        </el-table-column>
        <el-table-column
          prop='d1'
          label="Date"
          align='center'
          width="150">
          <template slot-scope="scope">
            <el-icon name="time"></el-icon>
            <span style="margin-left: 10px">{{ scope.row.d1 }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop='c1'
          label="Work Center"
          align='center'
          width="150">
        </el-table-column>
        <el-table-column
          prop='c2'
          label="SAP Part"
          align='center'
          width="150">
        </el-table-column>
        <el-table-column
          prop='c3'
          label="Lot No."
          align='center'
          width="150">
        </el-table-column>
        <el-table-column
          prop='i1'
          label="Lot Size"
          align='center'
          width="150">
        </el-table-column>
        <el-table-column
          prop='i2'
          label="QTY"
          align='center'
          width="100">
          <template slot-scope="scope">  
            <span style="color:red">{{ scope.row.i2 }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="operation"
          align='center'
          label="Actions"
          fixed="right"
          width="180">
          <template slot-scope='scope'>
            <el-button 
              type="warning" 
              icon='edit' 
              size="small"
              @click='handleEdit(scope.$index,scope.row)'>编辑</el-button>
            <el-button 
              type="danger" 
              icon='delete' 
              size="small"
              v-if="user.role=='admin'"
              @click='handleDelete(scope.$index,scope.row)'>删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- pagination -->
      <el-row>
        <el-col :span='24'>
          <div class="pagination">
            <el-pagination
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page.sync="paginations.page_index"
              :page-sizes="paginations.page_sizes"
              :page-size="paginations.page_size"
              :layout="paginations.layout"
              :total="paginations.total">
            </el-pagination>
          </div>
        </el-col>
      </el-row>
    </div>
    <DialogAdd :dialog='dialog' :formData='formData' @update='getWip'></DialogAdd>
  </div>
</template>

<script>
import DialogAdd from '../components/dialog_add'

export default{
  name: 'wiplist',
  data(){
    return{
      search_data:{
        startTime: '',
        endTime: ''
      },
      paginations:{
        page_index: 1,
        total: 0,
        page_size: 5,
        page_sizes: [5,10,15,20],
        layout:'total,sizes,prev,pager,next,jumper'
      },
      tableData: [], //for pagination
      filterTableData: [], //for search filter
      allTableData: [],
      formData:{
          //id:'',
          c1:'', //work center
          c2:'',
          c3:'',
          i1:'',
          i2:'',
          // d1:'',
          o1:''
      },
      dialog: {
        show: false,
        title: '',
        option: 'edit'
      }
    }
  },
  computed:{
    user(){
      return this.$store.getters.user; //for user right management
    }
  },
  created(){
    this.getWip();
  },
  methods:{
    getWip(){
      this.$axios
        .get('/api/rms')
        .then(res=>{
          // this.tableData=res.data.rows;
          this.allTableData=res.data.rows;
          this.filterTableData=res.data.rows;
          this.setPaginations();
        })
        .catch(err=>{
          console.log(err)
        });
    },
    //filter search
    handleSearch(){
      if(!this.search_data.startTime || !this.search_data.endTime){
        this.$message({
          type: 'warning',
          message: 'Please select time'
        });
        this.getWip();
        return;
      };

      const sTime=this.search_data.startTime.getTime();
      const eTime=this.search_data.endTime.getTime();
      //filter data
      this.allTableData=this.filterTableData.filter(item=>{
        let date=new Date(item.d1);
        let time=date.getTime();
        return time>=sTime && time<=eTime;
      });
      //paginatioin
      this.setPaginations();
    },
    handleEdit(index,row){
      this.dialog ={
        show: true,
        title: 'Modify Record',
        option: 'edit'
      };

      // this.formData={}; //not work
      for (const key in Object(row)) {
        if (row[key]) {
          this.formData[key]=row[key];
        }else{
          delete this.formData[key]; //prevent mixing data
        }
      };
      // this.formData=row;
      // this.formData={
      //   c1: row.c1, //work center
      //   c2: row.c2,
      //   c3: row.c3,
      //   id: row.id,
      //   i2: row.i2,
      //   o1: row.o1
      // };
    },
    handleDelete(index,row){
      this.$axios.delete(`/api/rms/delete/${row.id}`)
      .then(res=>{
        this.$message("Deleted successfuly.")
        this.getWip();
      });
    },
    handleAdd(){
      this.dialog ={
        show: true,
        title: 'Add Record',
        option: 'add'
      };
      this.formData={};
    },
    //pagination
    setPaginations(){
      //set pagination properties
      this.paginations.total=this.allTableData.length;
      this.paginations.page_index=1;
      this.paginations.page_size=5;
      //set default pagination data
      this.tableData=this.allTableData.filter((item,index)=>{
        return index < this.paginations.page_size;
      })
    },
    handleSizeChange(page_size){
      this.paginations.page_index=1;
      this.paginations.page_size=page_size;
      //set default pagination data
      this.tableData=this.allTableData.filter((item,index)=>{
        return index < page_size;
      })

    },
    handleCurrentChange(page){
      let index=this.paginations.page_size * (page -1);
      let nums=this.paginations.page_size * page;
      let tables=[];
      for(let i=index;i<nums;i++){
        if(this.allTableData[i]){
          tables.push(this.allTableData[i]);
        }
        this.tableData=tables;
      }
    }
  },
  components:{
    DialogAdd
  }
}
</script>
<style scoped>
.fillContainer {
  width: 100%;
  height: 100%;
  padding: 16px;
  box-sizing: border-box;
}
.btnRight {
  float: right;
}
.pagination {
  text-align: right;
  margin-top: 10px;
}

</style>