<template>
<div class="dialog">
    <el-dialog
    :title='dialog.title'
    :visible.sync='dialog.show'
    :close-on-click-modal='false'
    :close-on-press-escape='false'
    :modal-append-to-body="false"
    >
        <div class="form">
            <el-form
            ref="form" 
            :model="formData"
            :rules="form_rules"
            label-width="120px" 
            style="margin:10px;width:auto;"
            >
                <el-form-item label='W/C'>
                    <el-select v-model="formData.c1" placeholder="Work Center">
                        <el-option
                        v-for="(wc, index) in wcList"
                        :key="index" 
                        :label="wc" :value="wc"
                        ></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item prop='c2' label="SAPPart">
                    <el-input type="c2" v-model="formData.c2"></el-input>
                </el-form-item>
                <el-form-item prop='c3' label="Lot No.">
                    <el-input type="lotno" v-model="formData.c3"></el-input>
                </el-form-item>
                <el-form-item prop='i1' label="Lot Size">
                    <el-input type="lotsize" v-model="formData.i1"></el-input>
                </el-form-item>
                <el-form-item prop='o1' label="Operator">
                    <el-input type="textarea" v-model="formData.o1"></el-input>
                </el-form-item>
                <el-form-item prop='i2' label="QTY">
                    <el-input v-model.number="formData.i2"></el-input>
                </el-form-item>
                <el-form-item  class="text_right">
                    <el-button @click="dialog.show = false">取 消</el-button>
                    <el-button type="primary" @click='onSubmit("form")'>Submit</el-button>
                </el-form-item>
            </el-form>
        </div>
    </el-dialog>
</div>
</template>

<script>
    export default {
        name: 'dialogAdd',
        data(){
            return{
                // formData:{
                //     //id:'',
                //     c1:'', //work center
                //     c2:'',
                //     c3:'',
                //     i1:'',
                //     i2:'',
                //     // d1:'',
                //     o1:''
                // },
                wcList: [
                    'MFO3','MFO4','MFO5','MFO6'
                ],
                form_rules: {
                    c2: [
                        { required: true, message: "SAPPart is required！", trigger: "blur" }
                    ],
                    c3: [
                        { required: true, message: "LotNo is requried", trigger: "blur" }
                    ],
                    o1: [
                        { required: true, message: "Operator is requried", trigger: "blur" }
                    ],
                    i2: [
                        { required: true, type:'number', message: "QTY must be a number", trigger: "blur" }
                    ]
                }
            }
        },
        props: {
            dialog: Object,
            formData: Object
        },
        methods: {
            onSubmit(form) {
                this.$refs[form].validate(valid => {
                    if (valid) {
                    // 表单数据验证完成之后，提交数据;
                        const url = this.dialog.option == "add" ? "add" : `edit/${this.formData.id}`;
                        this.$axios.post(`/api/rms/${url}`, this.formData).then(res => {
                            if(res.data.err){
                                // 操作Fail
                                this.$message({
                                    message: res.data.err,
                                    type: "error"
                                });
                            }else{
                                // 操作成功
                                this.$message({
                                    message: "保存成功！",
                                    type: "success"
                                });
                            };
                            this.dialog.show = false;
                            this.$emit("update");
                        });
                    }
                });
            }
        }
        
    }
</script>

<style lang="css" scoped>

</style>