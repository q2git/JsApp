import Vue from 'vue'
import Router from 'vue-router'
import Index from './views/index'
import Register from './views/register'
import NotFound from './views/404'
import Login from './views/login'
import Home from './views/home'
import UserInfo from './views/userinfo'
import WipList from './views/wiplist'

Vue.use(Router)

//route table
const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      redirect: '/index'
    },
    {
      path: '/index',
      name: 'index',
      component: Index,
      children:[
        {path: '', component: Home},
        {path: '/home', name: 'home', component: Home},
        {path: '/userinfo', name: 'userinfo', component: UserInfo},
        {path: '/wiplist', name: 'wiplist', component: WipList}
      ]
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '*',
      name: '/404',
      component: NotFound
    }
  ]
})

//router guarder
router.beforeEach((to, from, next)=>{
  const isLogin=localStorage.eleToken ? true : false; //check if jwt token 'eleToken' is exist
  if(to.path=='/login' || to.path=='/register'){
    next();
  }else{
    isLogin ? next() : next('/login'); //if not exist, jump to login page
  }
})


export default router;