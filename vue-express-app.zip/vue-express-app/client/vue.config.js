
module.exports = {
    publicPath: process.env.NODE_ENV === "production" ? "./" : "/",
    outputDir: "dist", 
    assetsDir: "assets",//static resources (js、css、img、fonts) 
    lintOnSave: process.env.NODE_ENV !== 'production', //disable eslint: true | false | error

    devServer: {
        host: "localhost",
        port: 8080, 
        https: false, 
        open: true,
        proxy: {
            "/api": {
                target: "http://localhost:5000/api/",
                ws: true,  
                changeOrigin: true, 
                pathRewrite: {
                    '^/api': ''
                }
            }
        }
    }
}
  