const db=require('./db');
const bcrypt = require('bcrypt')

// db.add({
//         tableName:'Users',
//         params:{email:'hell@world.com',name:'Hell'}
//     })
//     .then(res=>{
//         console.log(res);})

//password encryption
const crypt = function(psw){
    
 return bcrypt.hashSync(psw, 1);

}

let txt = crypt('tesdfdft')
console.log(txt)
console.log(bcrypt.compareSync('tesdfdft', txt))
console.log(bcrypt.compareSync('asdf', txt))