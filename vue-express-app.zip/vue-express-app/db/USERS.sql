CREATE TABLE Users
(
    id INT NOT NULL PRIMARY KEY IDENTITY, -- primary key column
    name [NVARCHAR](50) NOT NULL UNIQUE,
    email [NVARCHAR](50),
    password [NVARCHAR](200),
    date [DATE] DEFAULT GETDATE(),
    role NVARCHAR(50)
    -- specify more columns here
);
GO
