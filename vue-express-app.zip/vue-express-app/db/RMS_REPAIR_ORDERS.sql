-- DRMS_REPAIR_ORDERSP TABLE [RMS_REPAIR_ORDERS]
-- GO
IF OBJECT_ID('[RMS_REPAIR_ORDERS]', 'U') IS  NULL
BEGIN
    -- Create the table in the specified schema
    CREATE TABLE [RMS_REPAIR_ORDERS]
    (
        id INT NOT NULL PRIMARY KEY IDENTITY, -- primary key column
        c1 [NVARCHAR](50) NOT NULL, -- floor
        c2 [NVARCHAR](50), -- sappart
        c3 [NVARCHAR](50), -- lotno

        i1 [INT], -- lotsize
        i2 [INT], -- failure qty
        i3 [INT], -- urgent level

        o1 [NVARCHAR](50), -- operator1
        d1 [DATETIME] DEFAULT GETDATE(), -- created date
        o2 [NVARCHAR](50), -- operator2
        d2 [DATETIME], -- accepted date
        o3 [NVARCHAR](50), -- operator3
        d3 [DATETIME], -- handled date
        o4 [NVARCHAR](50), -- operator4
        d4 [DATETIME], -- retrieved date
        o5 [NVARCHAR](50), -- operator5
        d5 [DATETIME], -- closed date

        -- specify more columns here
    )
END

INSERT INTO [RMS_REPAIR_ORDERS]
([c1], [c2], [c3], [i1], [i2], [i3], [o1], [o2], [d2])
VALUES
('MFO7', 'F01U027201', '3236001', 96, 3, 0, '88008801', NULL, NULL),
('MFO8', 'F01U169501', '3238003', 36, 2, 0, '88008802', '88008803', GETDATE())
GO

SELECT * FROM [RMS_REPAIR_ORDERS]
GO