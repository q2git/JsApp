const express = require('express')
const router = express.Router()
const db = require('../../db/db.js')
const bcrypt = require('bcrypt') //password encryption
const jwt = require('jsonwebtoken') 
const passport = require('passport') //verify token


//GET api/users/test
//access Public
router.get('/test',(req,res)=>{
    res.json({msg:'user works'})
})

//GET api/users
//access Public
router.get('/', (req,res)=>{
    db.querySql("select * from Users").then(resolve=>{
        res.send(resolve);
    }).catch(err=>{
        console.log(err);
    })
})

//POST api/users/register
//access Public
router.post('/register',(req,res)=>{
    const name = req.body.name;
    const password = req.body.password;
    const email = req.body.email;
    const role = req.body.role;
    //check the name in database
    db.findOne({
        tableName:'Users',
        whereSql:'name=@name',
        params:{'name':name}
    })
    .then(resolve=>{
        if(resolve.rows){
            return res.status(404).json('user already existed!');
        }
        //add new user
        db.add({
            tableName:'Users',
            params:{
                'email': email,
                'name': name,
                'password': bcrypt.hashSync(password, 10),
                'role': role
            }
        })
        .then(resolve=>{
            res.json(resolve)
        })
        .catch(err=>{
            console.log(err);
        })

    })
    .catch(err=>{
        console.log(err);
    })    

})

//POST api/users/login
//get JWT token
//access Public
router.post('/login',(req,res)=>{
    console.log(req.body);
    const name = req.body.name;
    const password = req.body.password;
    //query database
    db.findOne({
        'tableName':'Users',
        'whereSql':'name=@name',
        'params':{'name':name}
    })
    .then(resolve=>{
        let record = resolve.rows;
        if(!record){
            return res.status(404).json('name not exists!');
        }

        //compare password
        bcrypt.compare(password, record.password)
            .then(isMatch=>{
                if(isMatch){
                    //json web token
                    const rule = {id:record.id,name:record.name,role:record.role};
                    jwt.sign(rule,'secret',{expiresIn:3600},(err,token)=>{
                        if(err) throw err;
                        res.json({
                            success:true,
                            //token must be 'Bearer ' + token
                            token:'Bearer ' + token
                        });
                    });
                    // res.json({msg:'success'});
                }else{
                    return res.status(400).json('password incorrect');
                }
            })
        // res.json(resolve);
        // console.log(resolve);
    })
    .catch(err=>{
        console.log(err);
    })
})

//GET api/users/current
//JWT authentication required
//access Private
router.get('/current',passport.authenticate('jwt',{session:false}),
(req,res)=>{
    console.log(req.user) //req.user contains the jwt rule data
    res.json(req.user)
})


module.exports = router