const express = require('express')
const router = express.Router()
const db = require('../../db/db.js')
const passport = require('passport') //verify token

const tableName='RMS_REPAIR_ORDERS'

//GET api/rms/test
//access Public
router.get('/test',(req,res)=>{
    res.json({msg:'rms works'})
})

//POSt api/rms/add
//add record
//access Private
router.post('/add',passport.authenticate('jwt',{session: false}),
(req,res)=>{
    //add new user
    db.add({
        tableName: tableName,
        params:{...req.body}
    })
    .then(resolve=>{
        res.json(resolve)
        console.log(resolve.rows[0].id);
    })
    .catch(err=>{
        console.log(err);
    })
    
})

//GET api/rms
//get all records
//access Private
router.get('/', passport.authenticate('jwt',{session: false}),
(req,res)=>{
    //add new user
    db.findAll({
        tableName: tableName,
        // displayColumns: 'id,c1,c2,c3,o1,d1',
        // whereSql:'c1=@floor',
        // params:{floor:'MFO6'}
    })
    .then(resolve=>{
        res.json(resolve)
        console.log(resolve.rowSize);
    })
    .catch(err=>{
        console.log(err);
    })    
})

//GET api/rms/:id
//e.g.: http://127.0.0.1:5000/api/rms/3
//get one record
//access Private
router.get('/:id', passport.authenticate('jwt',{session: false}),
(req,res)=>{
    //add new user
    db.findOne({
        tableName: tableName,
        // displayColumns: 'id,c1,c2,c3,o1,d1',
        whereSql:'id=@id',
        params:{id: req.params.id}
    })
    .then(resolve=>{
        res.json(resolve.rows)
    })
    .catch(err=>{
        console.log(err);
    })    
})

//POSt api/rms/edit/:id
//update record
//access Private
router.post(
    '/edit/:id', 
    passport.authenticate('jwt',{session: false}),
    (req,res)=>{
        //add new user
        db.update({
            tableName: tableName,
            whereSql:'id=@id',
            params:{...req.body, id: req.params.id}
        })
        .then(resolve=>{
            res.json(resolve)
            // console.log(resolve);
        })
        .catch(err=>{
            console.log(err);
        })
    }
)

//DELETE api/rms/delete/:id
//delete a record
//access Private
router.delete(
    '/delete/:id', 
    passport.authenticate('jwt',{session: false}),
    (req,res)=>{
        //add new user
        db.del({
            tableName: tableName,
            whereSql:'id=@id',
            params:{id: req.params.id}
        })
        .then(resolve=>{
            res.json(resolve)
        })
        .catch(err=>{
            console.log(err);
        })
    }
)


module.exports = router