var express = require('express');
var db = require('../db/db.js');
var moment = require('moment');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next){
    db.querySql("select top 5* from WIP where floor='MFO7'").then(resolve=>{
        res.send({
            lastUpdated:moment().format('YYYY-MM-DD hh:mm:ss'),
            ...resolve})
    }).catch(err=>{
        console.log(err);
    })
})

router.get('/delete/:id', function (req, res, next) {//删除一条id对应的news表的数据
    var id = req.params.id;
    db.del("where id = @id", {id:id}, "news", function(err, result){
        res.redirect('back');//返回前一个页面
    });
});

router.post('/update/:id', function (req, res, next) {//更新一条对应id的news表的数据
    var id = req.params.id;
    var content = req.body.content;
    db.update({content:content}, {id:id}, "news", function(err, result){
        res.redirect('back');
    });
});

module.exports = router;